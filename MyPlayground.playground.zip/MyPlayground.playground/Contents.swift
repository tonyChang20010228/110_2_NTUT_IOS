//: A UIKit based Playground for presenting user interface
  
import UIKit
import PlaygroundSupport


enum Day{
    case Monday
    case Thuesday
    case Wednsday
    case Thursday
    case Fireday
    case Saturday
    case Sunday
    
}
func daytype(for day:Day)->String
{
    switch  day{
    case .Saturday,.Sunday:
        return "Weekend"
    default:
        return "Weekday"
    }
}

var mon=Day.Monday
daytype(for: mon)
var thues=Day.Thuesday
daytype(for: thues)
var wed=Day.Wednsday
daytype(for: wed)
var sun=Day.Sunday
daytype(for: sun)
