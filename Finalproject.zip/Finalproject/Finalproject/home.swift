//
//  home.swift
//  Finalproject
//
//  Created by 張君瑋 on 22/06/2022.
//

import SwiftUI

struct home: View {
    var body: some View {
        Text(/*@START_MENU_TOKEN@*/"Hello, World!"/*@END_MENU_TOKEN@*/)
    }
}

struct home_Previews: PreviewProvider {
    static var previews: some View {
        home()
    }
}
