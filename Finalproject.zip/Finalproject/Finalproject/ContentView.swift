//
//  ContentView.swift
//  Finalproject
//
//  Created by 張君瑋 on 22/06/2022.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        Text("Hello, world!")
            .padding()
        TabView{
            home().tabItem{
                Label("home", systemImage: "house.circle")
            }
            report().tabItem{
                Label("report", systemImage: "folder")
                }
            addfile().tabItem{
                Label("", systemImage: "plus.circle")
            }
            budget().tabItem{
                Label("", systemImage: "dollarsign.circle")
            }
            setting().tabItem{
                Label("setting", systemImage: "gearshape")
            }
            
            
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
