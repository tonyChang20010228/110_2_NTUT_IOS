//
//  addfile.swift
//  Finalproject
//
//  Created by 張君瑋 on 22/06/2022.
//

import SwiftUI

struct addfile: View {
    @State private var inputdata = ""
    var body: some View {
        VStack{
            HStack{
                TextField("Your name:",text: $inputdata, prompt: Text("Your name")).padding().overlay(textFieldBorder).padding().padding(.top,50)
            }
            HStack{
                Button{
                
                }label: {
                    Text("eat")
                }.overlay(textFieldBorder).padding(.top,90)
                Button{
                    
                }label: {
                    Text("entertainment")
                }.overlay(textFieldBorder).padding(.top,90)
                Button{
                    
                }label: {
                    Text("residence")
                }.overlay(textFieldBorder).padding(.top,90)
            }
            HStack{
                Button{
                    
                }label: {
                    Text("health care")
                }.overlay(textFieldBorder).padding(.top,90)
                Button{
                    
                }label: {
                    Text("traffic")
                }.overlay(textFieldBorder).padding(.top,90)
                Button{
                    
                }label: {
                    Text("clothes")
                }.overlay(textFieldBorder).padding(.top,90)
            }
        }
    }
    var textFieldBorder: some View{
        RoundedRectangle(cornerRadius: 20).stroke(Color.green, lineWidth: 2)
    }}

struct addfile_Previews: PreviewProvider {
    static var previews: some View {
        addfile()
    }
}
