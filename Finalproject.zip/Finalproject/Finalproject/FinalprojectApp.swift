//
//  FinalprojectApp.swift
//  Finalproject
//
//  Created by 張君瑋 on 22/06/2022.
//

import SwiftUI

@main
struct FinalprojectApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
